var twentyfourhour = false;
var pad = true; // add 0 to hour < 10